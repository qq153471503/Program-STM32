#ifndef __IIC_H
#define __IIC_H
#include "sys.h" 


void IIC_Test(void);

#endif

