#ifndef __ZX_H_
#define __ZX_H_
#include "sys.h"
extern u8 line;

void gongzuo(void);


#endif 
