#ifndef __INIT_H
#define __INIT_H	 


	

void YJ_INIT(void);//��ʼ��		 				    
#endif

