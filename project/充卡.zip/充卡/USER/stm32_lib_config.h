

#ifndef __STM32_LIB_CONFIG_H__
#define __STM32_LIB_CONFIG_H__


#define _ADC
#define _BKP
#define _CAN
#define _CRC
#define _DAC
#define _DBGMCU
#define _DMA
#define _EXTI
#define _FLASH
#define _FSMC
#define _GPIO
#define _I2C
#define _IWDG
#define _NVIC
#define _PWR
#define _RCC
#define _RTC
#define _SDIO
#define _SPI
#define _SysTick
#define _TIM
#define _USART
#define _WWDG

#endif

